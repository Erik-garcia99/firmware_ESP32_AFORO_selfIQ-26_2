# Corrección de enlace ESP-IDF

La función tcp_close del programa entraba en conflicto con tcp_close de lwIP.
Se renombró a selfiq_tcp_close en los tres archivos, sin cambiar su comportamiento.

Copia main/main.c y main/modules/TCP/tcp_lib.c y tcp_lib.h sobre los respectivos
archivos de tu proyecto. Conserva credential_parser.h y tus demás módulos.

Desde la raíz del proyecto:
```bash
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```

No necesitas borrar la flash ni las credenciales NVS. No cambia CMakeLists.txt.
Las pruebas de host del código C se ejecutaron; no se recompiló con ESP-IDF aquí.
