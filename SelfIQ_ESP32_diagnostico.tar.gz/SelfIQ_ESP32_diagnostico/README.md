# SelfIQ ESP32 · Aprovisionamiento con diagnóstico v2

Revisión basada en tus seis archivos adjuntos del 9 de octubre. Incluye archivos
completos de reemplazo, no solo fragmentos. El parser credential_parser.h es
nuevo y debe copiarse también. El protocolo permanece compatible con la
Raspberry preparada antes: 192.168.50.1:5000, HEADER ABCD, ACK 5433, TLVs 69/75/70.

## Qué demuestra el log que enviaste

- La ESP no encontró credenciales en el namespace storage de NVS.
- Sí se asoció a SelfIQ-Admi, canal 6, con señal -21 dBm.
- Sí obtuvo DHCP: 192.168.50.105, gateway 192.168.50.1.
- No aparece todavía un intento TCP ni recepción de credenciales. No hay
  evidencia de conexión a tu Wi-Fi de casa.

El punto siguiente en tu app_main es update_tcp_config y luego setup_tcp.
No es posible atribuir la detención a una causa única solo con esas líneas.
Tu tcp_client empieza con {.sock=0}; tcp_cliente_init cierra ese descriptor antes
incluso del primer log de intento. 0 es válido (habitualmente stdin), no el
sentinela de socket inválido: debe empezar en -1. Puede afectar la consola,
pero el log no demuestra que haya sido la causa exacta. Además, connect() no
está limitado por SO_RCVTIMEO: una espera de conexión requiere su propio límite.

## Cambios

- tcp_client.sock=-1 y cierre solamente para descriptor válido.
- Log antes/después de configurar destino, crear socket y conectar.
- connect no bloqueante + select de 8 s; SO_ERROR comprueba conexión efectiva.
- 5 intentos TCP con pausas de 2 s, errno + strerror + orientación del error.
- Transferencia con plazo total de 15 s y progreso sin imprimir payload secreto.
- Recepción exacta: soporta fragmentación y no supone recv=trama.
- Parser TLV con campos obligatorios, límites, duplicados, NUL y truncamiento.
- MAX_DATA=160, SSID máximo 32 bytes, password máximo 64, usuario máximo 31.
  Personal admite passphrase 8–63; Enterprise admite password 1–64.
- NACK explica que la RPI aún no puede entregar credenciales y se reintenta.
- Wi-Fi: 5 intentos, cada uno hasta 30 s incluyendo asociación/DHCP; reporte de
  reason numérico y descripción. Un reason no siempre implica una única causa.
- Detiene/inicia el driver al cambiar/reintentar una red y espera STA_STOP de
  forma acotada, evitando dejar manual_disconnect=true después de un timeout.
- Guardado NVS solo tras verificar Wi-Fi definitivo e IP. AP temporal solo RAM
  (esp_wifi_set_storage(WIFI_STORAGE_RAM)), no perfil permanente del driver.
- Si falla una red NVS, vuelve a aprovisionamiento; si falla la red definitiva,
  vuelve al AP; tras una desconexión, reintenta la red definitiva antes del AP.
- Se reemplaza el aprovisionamiento con tareas de recepción/cola por una
  transacción secuencial en app_main. Esto evita crear/borrar tareas compartidas
  en cada reintento. No quedan tareas recv_task/tcp_process_task por registrar.
  Los símbolos globales anteriores no utilizados permanecen por compatibilidad.
- Se quitaron bloques de código viejo comentado/corrompido. Tus adjuntos no
  arrancaban tareas DHT/MQTT; esta revisión tampoco agrega adquisición de sensores.

La transacción secuencial no bloquea eventos Wi-Fi: ESP-IDF los ejecuta en otra
 tarea. Las esperas son acotadas y liberan CPU; los reintentos globales continúan
indefinidamente para que el dispositivo pueda recuperarse cuando vuelva el AP.

## Copiar al proyecto

Estructura de destino (adapta solo el directorio raíz de tu proyecto):

| Archivo del paquete | Archivo de tu proyecto |
|---|---|
| main/main.c | main/main.c |
| main/global.h | main/global.h |
| main/modules/WIFI/wifi_lib.c | main/modules/WIFI/wifi_lib.c |
| main/modules/WIFI/wifi_lib.h | main/modules/WIFI/wifi_lib.h |
| main/modules/TCP/tcp_lib.c | main/modules/TCP/tcp_lib.c |
| main/modules/TCP/tcp_lib.h | main/modules/TCP/tcp_lib.h |
| main/modules/TCP/credential_parser.h | main/modules/TCP/credential_parser.h |

Reemplaza los archivos existentes; no compiles versiones antiguas y nuevas a
la vez. Conserva tu CMakeLists.txt de proyecto y las fuentes de otros módulos.
El header nuevo no requiere agregarse a SRCS. El componente main debe incluir
su propio directorio (INCLUDE_DIRS ".") y registrar main.c, wifi_lib.c y tcp_lib.c.
El uso añadido de esp_timer requiere el componente esp_timer si tienes una
lista REQUIRES explícita. Si tu main declara REQUIRES, verifica también esp_wifi,
esp_event, esp_netif, nvs_flash, lwip y wpa_supplicant (esp_eap_client.h).

```bash
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```
No necesitas erase-flash para probar. Mantén tu target actual; estos adjuntos
usan ESP-IDF con esp_eap_client (API de las versiones modernas). No se incluyó
un sdkconfig inventado ni se cambió tu distribución de particiones.

El primer mensaje del nuevo binario debe contener:
`SelfIQ provisioning diagnostico v2: inicio (passwords ocultos)`.
Si no aparece, puedes estar ejecutando el binario anterior/otro puerto/proyecto,
o tener un nivel de logs que oculta INFO. Activa nivel INFO y monitor a 115200.

## Log esperado (ejemplo, no captura real)

```text
PASO 1: buscando credenciales guardadas en NVS
Sin credenciales NVS completas/utilizables: ESP_ERR_NVS_NOT_FOUND
PASO 2: configurar y conectar AP Raspberry SSID="SelfIQ-Admi"
Intento Wi-Fi 1/5 SSID="SelfIQ-Admi"; limite=30000 ms
Asociado al AP, canal=6; esperando DHCP/IP
IP=192.168.50.105 mascara=255.255.255.0 gateway=192.168.50.1
AP RASPBERRY completado
PASO 3: preparando TCP hacia Raspberry 192.168.50.1:5000
Preparando destino TCP: 192.168.50.1:5000
Destino TCP listo
Intento TCP 1/5 -> 192.168.50.1:5000 (limite 8000 ms)
Socket creado ...; iniciando connect()
TCP conectado a 192.168.50.1:5000
PASO 4: solicitando credenciales de red definitiva
TX solicitud: AB CD 02 01 00
RX cabecera=0x5433 LEN=...
Credenciales TLV validas: tipo=1 SSID="TuRedCasa" (sin mostrar password/usuario)
PASO 5: actualizando credenciales en RAM, SSID="TuRedCasa"
PASO 6: dejando AP y conectando red definitiva de la Raspberry
Intento Wi-Fi 1/5 SSID="TuRedCasa"; limite=30000 ms
IP=192.168.1.xxx ...
PASO 7: guardando credenciales verificadas en NVS
NVS guardada. Proximo arranque usara la red definitiva
LISTO: ESP32 conectada a red definitiva SSID="TuRedCasa". TCP de setup cerrado
```

Si no está el servidor, habrá errno y causa probable, sin quedarse en silencio.
Si responde `54 33 FF FF 00`, se informa NACK y no se señaliza éxito. Configura
primero la Raspberry en la página web; su servidor solo entrega credenciales
cuando ya conectó a la red definitiva. Si el AP cerró después de los 5 minutos,
la ESP no puede reabrirlo mediante un TCP que también está apagado: utiliza el
endpoint de reapertura de la Raspberry que ya se documentó.

## Si hay un fallo

En Raspberry:
```bash
sudo systemctl status selfiq --no-pager
sudo journalctl -u selfiq -n 80 --no-pager
sudo ss -ltnp 'sport = :5000'
```
Espera el listener de 192.168.50.1:5000 mientras el AP está abierto. Una ESP con
IP .50.x demuestra DHCP, pero no demuestra que el servidor escuche ni que esté
lista la red doméstica. Si no aparece el listener, primero resuelve la RPI.

El warning `Detected size(4096k)...header(2048k)` indica que el binario está
configurado con 2 MB y la flash detectada es de 4 MB. El log continuó y conectó
Wi-Fi, por lo que no demuestra el origen del bloqueo observado. Ajusta el tamaño
real en idf.py menuconfig; no cambies particiones o borres NVS sin necesidad.
Las letras corruptas de la captura tampoco identifican por sí solas la causa:
comprueba velocidad del monitor, cable y alimentación antes de atribuirlas a TCP.

## Enterprise y límites

Se conserva la configuración Enterprise por usuario/password de tus adjuntos;
no se ha validado una red institucional. Antes de usar UABC, configura y
verifica CA/servidor EAP en firmware con los parámetros de esa red. Los TLVs
actuales no transmiten CA ni dominio. El firmware sigue limitado a las redes
compatibles con tu hardware y ESP-IDF; no ofrece WPA3-only, EAP-TLS ni portales
cautivos. Esta revisión está pensada primero para probar WPA2 de tu casa.

## Validación realizada

`python3 tests/run_host_tests.py` compila con GCC el parser y tcp_lib.c real
contra adaptadores de prueba para ESP-IDF. Verifica límites y rechazo sin alterar
credenciales previas; usa AddressSanitizer/UndefinedBehaviorSanitizer y 50 000
tramas aleatorias. Prueba sockets locales reales: respuesta fragmentada válida,
NACK, TLV truncado, cierre con trama incompleta, tipo/acción inválidos, timeout
de respuesta y puerto rechazado con reintentos acotados. También compila main.c
y ejecuta wifi_lib.c con un driver/eventos simulados para verificar éxito,
cambio AP→Casa, cinco fallos, recuperación en el tercer intento y timeout.
No ejecuta radio Wi-Fi ni NVS real; no sustituye idf.py build/flash ni acredita
la conexión física ESP32→Raspberry→red doméstica. ESP-IDF no está instalado en
este entorno, así que el firmware completo no se compiló para tu placa.

Referencias de ESP-IDF usadas para revisar eventos y sockets:
- https://docs.espressif.com/projects/esp-idf/en/v5.4/esp32/api-guides/wifi.html
- https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/lwip.html
- https://github.com/espressif/esp-idf/blob/master/examples/protocols/sockets/non_blocking/main/non_blocking_socket_example.c
