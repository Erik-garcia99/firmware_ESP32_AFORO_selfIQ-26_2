/* Simulated ESP-IDF driver/events; executes the production Wi-Fi retry code. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_eap_client.h"
#include "modules/WIFI/wifi_lib.h"
#include "freertos/task.h"

TYPE_ESP_WIFI_T esp_wifi;
EventGroupHandle_t s_wifi_event_group;
esp_event_base_t WIFI_EVENT="WIFI",IP_EVENT="IP";
static void (*wifi_handler)(void *,esp_event_base_t,int32_t,void *);
static void (*ip_handler)(void *,esp_event_base_t,int32_t,void *);
static unsigned now, bits, calls, stops, starts;
static int scenario;
static wifi_config_t profile;
const char *esp_err_to_name(esp_err_t e) { return e==ESP_OK ? "ESP_OK" : "MOCK_ERROR"; }
EventGroupHandle_t xEventGroupCreate(void) { return &bits; }
EventBits_t xEventGroupSetBits(EventGroupHandle_t g,EventBits_t b) { (void)g; return bits|=b; }
EventBits_t xEventGroupClearBits(EventGroupHandle_t g,EventBits_t b) { (void)g; return bits&=~b; }
EventBits_t xEventGroupWaitBits(EventGroupHandle_t g,EventBits_t wanted,int clear,int all,TickType_t wait) {
    (void)g; (void)all;
    unsigned result=bits;
    if (!(result & wanted)) now+=wait;
    if (clear) bits&=~wanted;
    return result;
}
TickType_t xTaskGetTickCount(void) { return now; }
void vTaskDelay(TickType_t t) { now+=t; }
esp_err_t esp_netif_init(void) { return ESP_OK; }
void *esp_netif_create_default_wifi_sta(void) { return &bits; }
esp_err_t esp_event_loop_create_default(void) { return ESP_OK; }
esp_err_t esp_event_handler_register(esp_event_base_t b,int32_t id,void (*h)(void *,esp_event_base_t,int32_t,void *),void *a) {
    (void)id; (void)a; if(b==WIFI_EVENT)wifi_handler=h; else ip_handler=h; return ESP_OK;
}
esp_err_t esp_wifi_init(const wifi_init_config_t *c) { (void)c; return ESP_OK; }
esp_err_t esp_wifi_set_storage(int s) { assert(s==WIFI_STORAGE_RAM); return ESP_OK; }
esp_err_t esp_wifi_set_mode(int m) { assert(m==WIFI_MODE_STA); return ESP_OK; }
esp_err_t esp_wifi_set_config(int i,const wifi_config_t *c) { (void)i; profile=*c; return ESP_OK; }
esp_err_t esp_wifi_start(void) { starts++;wifi_handler(NULL,WIFI_EVENT,WIFI_EVENT_STA_START,NULL);return ESP_OK; }
esp_err_t esp_wifi_stop(void) { stops++;wifi_handler(NULL,WIFI_EVENT,WIFI_EVENT_STA_STOP,NULL);return ESP_OK; }
esp_err_t esp_wifi_connect(void) {
    calls++;
    if (scenario==1 || (scenario==2 && calls<3)) {
        wifi_event_sta_disconnected_t e={.reason=WIFI_REASON_AUTH_FAIL};
        wifi_handler(NULL,WIFI_EVENT,WIFI_EVENT_STA_DISCONNECTED,&e);
    } else if (scenario!=3) {
        wifi_event_sta_connected_t c={.channel=6};
        wifi_handler(NULL,WIFI_EVENT,WIFI_EVENT_STA_CONNECTED,&c);
        ip_event_got_ip_t e={.ip_info.ip.addr=105,.ip_info.netmask.addr=0,.ip_info.gw.addr=1};
        ip_handler(NULL,IP_EVENT,IP_EVENT_STA_GOT_IP,&e);
    }
    return ESP_OK;
}
esp_err_t esp_wifi_sta_enterprise_enable(void) { return ESP_OK; }
esp_err_t esp_wifi_sta_enterprise_disable(void) { return ESP_OK; }
void esp_eap_client_clear_identity(void) {}
void esp_eap_client_clear_username(void) {}
void esp_eap_client_clear_password(void) {}
esp_err_t esp_eap_client_set_identity(const uint8_t *v,int n) { (void)v;(void)n;return ESP_OK; }
esp_err_t esp_eap_client_set_username(const uint8_t *v,int n) { (void)v;(void)n;return ESP_OK; }
esp_err_t esp_eap_client_set_password(const uint8_t *v,int n) { (void)v;(void)n;return ESP_OK; }
int main(void) {
    s_wifi_event_group=xEventGroupCreate();
    esp_wifi.ssid="SelfIQ-Admi";esp_wifi.pswd="$elfIQ-4dmi-1";
    assert(wifi_connect_current(5,1000)==ESP_OK);
    assert(calls==1 && esp_wifi.connected && !memcmp(profile.sta.ssid,"SelfIQ-Admi",11));
    esp_wifi.ssid="Casa";esp_wifi.pswd="12345678";
    assert(wifi_connect_current(5,1000)==ESP_OK);
    assert(stops==1 && esp_wifi.connected && !memcmp(profile.sta.ssid,"Casa",4));
    scenario=1;calls=0;
    assert(wifi_connect_current(5,1000)==ESP_FAIL);
    assert(calls==5 && !esp_wifi.connected);
    scenario=2;calls=0;
    assert(wifi_connect_current(5,1000)==ESP_OK);
    assert(calls==3 && esp_wifi.connected);
    scenario=3;calls=0;unsigned before=now;
    assert(wifi_connect_current(2,1000)==ESP_FAIL);
    assert(calls==2 && !esp_wifi.connected && now-before==4000);
    scenario=0;calls=0;
    assert(wifi_connect_current(1,1000)==ESP_OK);
    assert(calls==1 && esp_wifi.connected);
    printf("Wi-Fi con driver simulado: exito, cambio AP->Casa, 5 fallos, exito en intento 3, timeout y recuperacion OK (starts=%u)\n",starts);
}
