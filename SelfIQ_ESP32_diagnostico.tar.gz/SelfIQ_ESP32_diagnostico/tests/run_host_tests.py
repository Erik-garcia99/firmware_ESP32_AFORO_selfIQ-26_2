#!/usr/bin/env python3
"""Actual parser/TCP C code, host adapters only. Not an ESP-IDF build."""
from pathlib import Path
import os, socket, subprocess, tempfile, threading, time
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    common=['gcc','-std=gnu11','-Wall','-Wextra','-Werror','-I'+str(root/'main'),
            '-I'+str(root/'main/modules/TCP'),'-I'+str(root/'tests/host_shims')]
    parser=Path(tmp)/'parser'
    subprocess.run(common+['-fsanitize=address,undefined','-fno-omit-frame-pointer',str(root/'tests/test_parser.c'),'-o',str(parser)],check=True)
    subprocess.run([str(parser)],check=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
    subprocess.run(common+['-fsyntax-only',str(root/'main/main.c'),str(root/'main/modules/WIFI/wifi_lib.c')],check=True)
    wifi=Path(tmp)/'wifi'
    subprocess.run(common+[str(root/'main/modules/WIFI/wifi_lib.c'),str(root/'tests/test_wifi_host.c'),'-o',str(wifi)],check=True)
    result=subprocess.run([str(wifi)],capture_output=True,text=True,timeout=5)
    if result.returncode: raise AssertionError(result.stderr)
    print(result.stdout.strip())
    client=Path(tmp)/'client'
    subprocess.run(common+['-DTCP_IO_TIMEOUT_MS=250','-DTCP_CONNECT_TIMEOUT_MS=250','-DTCP_MAX_ATTEMPTS=2',str(root/'main/modules/TCP/tcp_lib.c'),str(root/'tests/host_client.c'),'-o',str(client)],check=True)
    def exact(sock,n):
        b=b''
        while len(b)<n:
            part=sock.recv(n-len(b))
            if not part: raise AssertionError('Client closed early')
            b+=part
        return b
    cases=[('fragmentado',bytes.fromhex('5433111269044361736170083132333435363738'),0),
           ('NACK',bytes.fromhex('5433FFFF00'),1),
           ('TLV truncado',bytes.fromhex('5433051269044361'),1),
           ('trama incompleta',bytes.fromhex('5433111269'),1),
           ('tipo invalido',bytes.fromhex('5433023200'),1),
           ('timeout respuesta',b'',1)]
    for name,response,expected in cases:
        errors=[]
        with socket.socket() as server:
            server.bind(('127.0.0.1',0)); server.listen(); server.settimeout(5)
            port=server.getsockname()[1]
            def serve():
                try:
                    with server.accept()[0] as s:
                        s.settimeout(5)
                        assert exact(s,5)==bytes.fromhex('ABCD020100')
                        if not response: time.sleep(.6)
                        for byte in response:
                            s.sendall(bytes([byte])); time.sleep(.003)
                        if expected==0: assert exact(s,5)==bytes.fromhex('5433023001')
                except BaseException as e: errors.append(e)
            thread=threading.Thread(target=serve); thread.start()
            result=subprocess.run([str(client),str(port),str(expected)],capture_output=True,text=True,timeout=10)
            thread.join(6)
            if result.returncode: raise AssertionError(name+'\n'+result.stderr)
            if errors: raise errors[0]
            assert not thread.is_alive()
            print('TCP C contra servidor real local:',name,'OK')

    # A closed local port must report connect failure and finish bounded retries.
    with socket.socket() as closed:
        closed.bind(('127.0.0.1',0)); refused_port=closed.getsockname()[1]
    result=subprocess.run([str(client),str(refused_port),'1'],capture_output=True,text=True,timeout=5)
    assert result.returncode==3 and 'errno=' in result.stderr, result.stderr
    print('TCP C: puerto rechazado y reintentos acotados OK')
