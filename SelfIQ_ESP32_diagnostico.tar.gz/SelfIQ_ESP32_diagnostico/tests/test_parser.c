#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "credential_parser.h"

static unsigned tlv(uint8_t *b, unsigned offset, uint8_t id, char byte, unsigned len) {
    b[offset++] = id; b[offset++] = len;
    memset(b + offset, byte, len); return offset + len;
}
int main(void) {
    selfiq_credentials_t out = {.ssid="unchanged"}, original;
    const char *why;
    uint8_t b[161] = {0x12};
    unsigned n = tlv(b, 1, 0x69, 'S', 32);
    n = tlv(b, n, 0x70, 'P', 63);
    assert(selfiq_decode_credentials(0x5433,n,b,&out,&why));
    assert(strlen(out.ssid)==32 && strlen(out.password)==63 && out.kind==1);
    b[0]=0x22;
    n=tlv(b,1,0x69,'S',32); n=tlv(b,n,0x75,'U',31); n=tlv(b,n,0x70,'P',64);
    assert(n==134 && selfiq_decode_credentials(0x5433,n,b,&out,&why));
    assert(strlen(out.username)==31 && strlen(out.password)==64 && out.kind==2);
    original=out;
    assert(!selfiq_decode_credentials(0xabcd,n,b,&out,&why));
    assert(!memcmp(&out,&original,sizeof(out)));
    assert(!selfiq_decode_credentials(0x5433,n-1,b,&out,&why));
    assert(!selfiq_decode_credentials(0x5433,0,b,&out,&why));
    assert(!selfiq_decode_credentials(0x5433,255,b,&out,&why));
    b[0]=0x21; assert(!selfiq_decode_credentials(0x5433,n,b,&out,&why));
    b[0]=0x22; b[2]=33; assert(!selfiq_decode_credentials(0x5433,n,b,&out,&why));
    b[0]=0x12;
    n=tlv(b,1,0x69,'S',4); n=tlv(b,n,0x70,'P',8); n=tlv(b,n,0x69,'S',4);
    assert(!selfiq_decode_credentials(0x5433,n,b,&out,&why));
    n=tlv(b,1,0x69,'S',4); n=tlv(b,n,0x75,'U',4); n=tlv(b,n,0x70,'P',8);
    assert(!selfiq_decode_credentials(0x5433,n,b,&out,&why));
    n=tlv(b,1,0x69,'S',4); n=tlv(b,n,0x70,'P',7);
    assert(!selfiq_decode_credentials(0x5433,n,b,&out,&why));
    n=tlv(b,1,0x69,'S',4); n=tlv(b,n,0x70,'P',8);
    b[4]=0; assert(!selfiq_decode_credentials(0x5433,n,b,&out,&why));
    /* Deterministic malformed-frame fuzz; output unchanged on every rejection. */
    srand(7);
    for (int run=0; run<50000; ++run) {
        for (unsigned i=0;i<sizeof(b);++i) b[i]=rand() & 255;
        n=rand()%162;
        original=out;
        if (!selfiq_decode_credentials(0x5433,n,b,&out,&why))
            assert(!memcmp(&out,&original,sizeof(out)));
    }
    puts("Parser C: limites, duplicados, truncamiento, NUL y 50000 tramas aleatorias OK");
}
