#ifndef HOST_EVENTS_H
#define HOST_EVENTS_H
typedef void *EventGroupHandle_t;
#endif
#include "FreeRTOS.h"
typedef unsigned EventBits_t;
EventGroupHandle_t xEventGroupCreate(void);
EventBits_t xEventGroupSetBits(EventGroupHandle_t,EventBits_t);
EventBits_t xEventGroupClearBits(EventGroupHandle_t,EventBits_t);
EventBits_t xEventGroupWaitBits(EventGroupHandle_t,EventBits_t,int,int,TickType_t);
