#ifndef HOST_FREERTOS_H
#define HOST_FREERTOS_H
#include <stdint.h>
typedef uint32_t TickType_t;
#define pdMS_TO_TICKS(ms) (ms)
#define BIT0 (1u << 0)
#define BIT2 (1u << 2)
#define BIT3 (1u << 3)
#define BIT4 (1u << 4)
#define BIT5 (1u << 5)
#define BIT6 (1u << 6)
#define BIT7 (1u << 7)
#define BIT8 (1u << 8)
#define BIT9 (1u << 9)
#define BIT11 (1u << 11)
#endif
#ifndef HOST_FREERTOS_EXTRA
#define HOST_FREERTOS_EXTRA
#define BIT10 (1u << 10)
#define pdTRUE 1
#define pdFALSE 0
#define portTICK_PERIOD_MS 1
#endif
