#ifndef HOST_QUEUE_H
#define HOST_QUEUE_H
typedef void *QueueHandle_t;
#endif
