#ifndef HOST_TASK_H
#define HOST_TASK_H
#include "FreeRTOS.h"
void vTaskDelay(TickType_t delay);
#endif
TickType_t xTaskGetTickCount(void);
