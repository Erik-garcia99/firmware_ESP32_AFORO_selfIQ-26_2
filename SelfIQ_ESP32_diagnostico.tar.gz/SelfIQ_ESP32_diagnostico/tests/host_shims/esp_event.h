#ifndef HOST_EVENT_API
#define HOST_EVENT_API
#include <stdint.h>
#include "esp_err.h"
typedef const char *esp_event_base_t;
extern esp_event_base_t WIFI_EVENT,IP_EVENT;
#define ESP_EVENT_ANY_ID -1
#define WIFI_EVENT_STA_START 1
#define WIFI_EVENT_STA_STOP 2
#define WIFI_EVENT_STA_CONNECTED 3
#define WIFI_EVENT_STA_DISCONNECTED 4
#define IP_EVENT_STA_GOT_IP 5
#define IP_EVENT_STA_LOST_IP 6
esp_err_t esp_event_loop_create_default(void);
esp_err_t esp_event_handler_register(esp_event_base_t,int32_t,void (*)(void *,esp_event_base_t,int32_t,void *),void *);
#endif
