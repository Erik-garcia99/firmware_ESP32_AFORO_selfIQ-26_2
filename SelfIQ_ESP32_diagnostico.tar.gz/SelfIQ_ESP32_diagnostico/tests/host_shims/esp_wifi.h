#ifndef HOST_WIFI_API
#define HOST_WIFI_API
#include <stdint.h>
#include "esp_err.h"
#define WIFI_REASON_NO_AP_FOUND 201
#define WIFI_REASON_AUTH_FAIL 202
#define WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT 15
#define WIFI_REASON_HANDSHAKE_TIMEOUT 204
#define WIFI_REASON_BEACON_TIMEOUT 200
#define WIFI_REASON_ASSOC_FAIL 203
#define WIFI_STORAGE_RAM 0
#define WIFI_MODE_STA 1
#define WIFI_AUTH_WPA2_PSK 3
#define WIFI_IF_STA 0
typedef struct { unsigned channel; } wifi_event_sta_connected_t;
typedef struct { unsigned reason; } wifi_event_sta_disconnected_t;
typedef struct { int dummy; } wifi_init_config_t;
#define WIFI_INIT_CONFIG_DEFAULT() {0}
typedef union { struct { uint8_t ssid[32],password[64]; struct { int authmode; } threshold; } sta; } wifi_config_t;
esp_err_t esp_wifi_init(const wifi_init_config_t *);
esp_err_t esp_wifi_set_storage(int);
esp_err_t esp_wifi_set_mode(int);
esp_err_t esp_wifi_start(void);
esp_err_t esp_wifi_stop(void);
esp_err_t esp_wifi_connect(void);
esp_err_t esp_wifi_set_config(int,const wifi_config_t *);
esp_err_t esp_wifi_sta_enterprise_enable(void);
esp_err_t esp_wifi_sta_enterprise_disable(void);
#endif
