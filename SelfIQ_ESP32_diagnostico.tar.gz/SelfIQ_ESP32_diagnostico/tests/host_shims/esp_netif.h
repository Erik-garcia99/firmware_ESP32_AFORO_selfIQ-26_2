#ifndef HOST_NETIF_H
#define HOST_NETIF_H
#include <stdint.h>
typedef struct { uint32_t addr; } esp_ip4_addr_t;
#endif
#ifndef HOST_NETIF_EXTRA
#define HOST_NETIF_EXTRA
#include "esp_err.h"
#define IPSTR "%u.%u.%u.%u"
#define IP2STR(p) 1u,2u,3u,(unsigned)((p)->addr)
typedef struct { struct { esp_ip4_addr_t ip,netmask,gw; } ip_info; } ip_event_got_ip_t;
esp_err_t esp_netif_init(void);
void *esp_netif_create_default_wifi_sta(void);
#endif
