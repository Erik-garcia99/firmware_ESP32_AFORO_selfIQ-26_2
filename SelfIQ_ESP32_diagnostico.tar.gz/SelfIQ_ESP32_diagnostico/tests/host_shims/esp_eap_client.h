#ifndef HOST_EAP_API
#define HOST_EAP_API
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
void esp_eap_client_clear_identity(void);
void esp_eap_client_clear_username(void);
void esp_eap_client_clear_password(void);
esp_err_t esp_eap_client_set_identity(const uint8_t *,int);
esp_err_t esp_eap_client_set_username(const uint8_t *,int);
esp_err_t esp_eap_client_set_password(const uint8_t *,int);
#endif
