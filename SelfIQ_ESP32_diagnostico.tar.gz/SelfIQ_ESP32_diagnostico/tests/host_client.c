#define _POSIX_C_SOURCE 200809L
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "global.h"
#include "modules/TCP/tcp_lib.h"
#include "modules/WIFI/wifi_lib.h"
TYPE_TCP_CLIENT_T tcp_client = {.sock=-1};
TYPE_ESP_WIFI_T esp_wifi = {.connected=1};
TYPE_SEND_INFO_T send_info;
EventGroupHandle_t g_tcp_event_group;
int64_t esp_timer_get_time(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return (int64_t)t.tv_sec*1000000 + t.tv_nsec/1000;
}
void vTaskDelay(TickType_t ms) {
    struct timespec t = {.tv_sec=ms/1000,.tv_nsec=(ms%1000)*1000000L};
    nanosleep(&t,NULL);
}
int main(int argc,char **argv) {
    if (argc != 3) return 2;
    int expected=atoi(argv[2]);
    if (update_tcp_config("127.0.0.1",atoi(argv[1]))!=ESP_OK || tcp_cliente_init()!=ESP_OK) return 3;
    selfiq_credentials_t creds = {0};
    esp_err_t e=tcp_request_wifi(&creds);
    tcp_close();
    free(tcp_client.host_ip);
    if (expected == 0) {
        if (e!=ESP_OK || strcmp(creds.ssid,"Casa") || strcmp(creds.password,"12345678")) return 4;
    } else if (e==ESP_OK) return 5;
    return 0;
}
